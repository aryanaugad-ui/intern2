const chatBox = document.getElementById("chatBox");
const userInput = document.getElementById("userInput");
const sendButton = document.getElementById("sendButton");
const typingIndicator = document.getElementById("typingIndicator");


function addMessage(message, sender) {

    const messageDiv = document.createElement("div");

    messageDiv.classList.add("message");

    if (sender === "user") {

        messageDiv.classList.add("user-message");

        messageDiv.innerHTML = `
            <div class="message-content">
                <p>${message}</p>
                <span>Just now</span>
            </div>
        `;

    } else {

        messageDiv.classList.add("bot-message");

        messageDiv.innerHTML = `
            <div class="avatar">🤖</div>

            <div class="message-content">
                <p>${message}</p>
                <span>Just now</span>
            </div>
        `;
    }

    chatBox.appendChild(messageDiv);

    chatBox.scrollTop = chatBox.scrollHeight;
}


function getBotResponse(input) {

    input = input.toLowerCase().trim();

    if (input === "hello" || input === "hi" || input === "hey") {

        return "Hello! 👋 How can I help you today?";

    }

    else if (input === "how are you" || input === "how are you?") {

        return "I'm doing great! Thanks for asking. 😊";

    }

    else if (input === "what is ai" || input === "what is ai?") {

        return "AI stands for Artificial Intelligence. It enables computers to perform tasks that normally require human intelligence.";

    }

    else if (input === "what is your name" || input === "what is your name?") {

        return "My name is AI Buddy! 🤖";

    }

    else if (input === "who created you" || input === "who created you?") {

        return "I was created as a Rule-Based AI project.";

    }

    else if (input === "help") {

        return "You can ask me about AI, my name, or how I am doing.";

    }

    else if (input === "thank you" || input === "thanks") {

        return "You're welcome! 😊";

    }

    else if (input === "bye" || input === "goodbye") {

        return "Goodbye! Have a great day! 👋";

    }

    else {

        return "I'm sorry, I don't understand that yet. 🤔";

    }
}


function sendMessage() {

    const message = userInput.value.trim();

    if (message === "") {
        return;
    }


    // Display user's message
    addMessage(message, "user");


    // Get bot response
    const response = getBotResponse(message);


    // Show typing indicator
    typingIndicator.style.display = "block";


    // Wait 2 seconds
    setTimeout(function () {

        // Hide typing indicator
        typingIndicator.style.display = "none";

        // Display bot response
        addMessage(response, "bot");

    }, 2000);


    // Clear input
    userInput.value = "";

    // Focus input
    userInput.focus();
}


// Send button
sendButton.addEventListener("click", sendMessage);


// Enter key
userInput.addEventListener("keydown", function (event) {

    if (event.key === "Enter") {

        sendMessage();

    }

});