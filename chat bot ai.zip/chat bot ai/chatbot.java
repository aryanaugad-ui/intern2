import java.util.Scanner;
import java.util.Random;
public class chatbot {
    public static void main(String args []){
        Scanner sc = new Scanner(System.in);
        Random random = new Random();

        System.out.println("🤖Chatbot:Hello!I'M your AI Chatbot!");
        System.out.println("Type bye to exit");
        while(true){
            System.out.println("You:");
            String input = sc.nextLine();
            if (input.equalsIgnoreCase ("bye")){
                System.out.println("🤖Chatbot:Goodbye!Have a great day!");
                break;
            }
            if(input.equalsIgnoreCase("Hello")||
            input.equalsIgnoreCase("Hi")||
            input.equalsIgnoreCase("Hey")){
                int response = random.nextInt(3);
                if(response == 0){
                    System.out.println("🤖Chatbot:Hello!How can I help you?");
                }
                else if(response == 1){
                    System.out.println("🤖Chatbot:Hi there!What can I do for you?");
                }
                else{
                    System.out.println("🤖Chatbot:Hey!How's it going?");
                }

            }
            else if(input.equalsIgnoreCase("How are you?")){
                System.out.println("🤖Chatbot:I'M doing well,thanks for asking!");

            }
            else if(input.equalsIgnoreCase("What is Ai?")){
                System.out.println("🤖Chatbot:Ai stands for Artificial intalligence!");

            }
            else if(input.equalsIgnoreCase("What is your name?")){
                System.out.println("🤖Chatbot:My name is AI buddy!");
            }
            else if(input.equalsIgnoreCase("Who created you?")){
                System.out.println("🤖Chatbot:I was Created as rule-based AI project ");
            }
            else if(input.equalsIgnoreCase("Help")){
                System.out.println("🤖Chatbot:You can ask me about AI, my name, or how I am doing.");
            }
            else if(input.equalsIgnoreCase("Thank you")){
                System.out.println("🤖Chatbot:Your Welcome!😊");
            }
            else{
                System.out.println("🤖Chatbot:I'M sorry,I dont Understand that");
            }


            }
            sc.close();
        }
    }
            